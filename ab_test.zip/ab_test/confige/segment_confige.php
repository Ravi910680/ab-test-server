<?php
$servername = "segment.cooou66jo1js.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="segment_list";

$seg_conn = mysqli_connect($servername, $username, $password,$db);



?>

