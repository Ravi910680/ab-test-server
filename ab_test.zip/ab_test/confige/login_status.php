<?php
session_start();

$res_data=array("status"=>0,"message"=>"");

  if (!isset($_SESSION['id'])) { //if you have more session-vars that are needed for login, also check if they are set and refresh them as well
    $res_data['status']=1;
  }else{
    $res_data['status']=2;
  }

echo json_encode($res_data);


 ?>

