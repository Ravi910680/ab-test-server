<?php


$date = strtotime("Fri Jan 28 2022 15:30:00");

echo $date;

 ?>
