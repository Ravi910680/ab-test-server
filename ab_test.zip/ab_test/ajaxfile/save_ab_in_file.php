<?php
session_start();


$name_of_test=$_POST['name_of_fl_ab'];
$con_of_test=$_POST['data_of_post'];
$fl_name=$_POST['file_name_set'];
$id=$_SESSION['id'];


$res_arr=array("status"=>1,"message"=>'');
if(strlen($fl_name)>5){

$name_of_file=$fl_name;

}else{
$name_of_file=base64_encode($id."^".$name_of_test);
}

$myfile = fopen("../saved_ab/".$name_of_file.".html", "w") or die("Unable to open file!");
$txt = $con_of_test;
fwrite($myfile, $txt);

fclose($myfile);


$res_arr['message']=$name_of_file;

echo json_encode($res_arr);




 ?>
