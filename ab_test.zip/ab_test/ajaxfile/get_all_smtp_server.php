<?php
session_start();



require("../confige/account_db.php");


$arr_resp=array();

$id=$_SESSION['id'];




$sel_all_smtp="select smtp_def from `userinfo` where id='$id'";


$result = $conn_acc->query($sel_all_smtp);

$row = $result->fetch_assoc();

$smtp_id=$row['smtp_def'];


$servername = "database-1.cildipxt35b8.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="smtp_data";
$conn_smtp = mysqli_connect($servername, $username, $password,$db);






$sel_all_smtp="select * from smtp_server_data where id='$id' or smtp_id='$smtp_id'";
$result = $conn_smtp->query($sel_all_smtp);

if ($result->num_rows > 0) {

  while($row = $result->fetch_assoc()) {

array_push($arr_resp, $row);


  }

echo json_encode($arr_resp);

} else {
  echo 0;
}





?>
