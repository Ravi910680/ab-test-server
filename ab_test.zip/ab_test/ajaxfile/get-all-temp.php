<?php

require("../confige/template_confige.php");

session_start();

    $mail=$_SESSION["email"];
$id=$_SESSION["id"];



$query_for_temp="SELECT * FROM temp_details WHERE id='$id'";

$tempresult = $template->query($query_for_temp);
$array_temp_det=array();
while($row = $tempresult->fetch_assoc()) {

	$mytemp['name'] = $row['tempname'];
$mytemp['dateofcrt'] = $row['date'];


array_push($array_temp_det,$mytemp);
}

$mytempjson = json_encode($array_temp_det);
echo $mytempjson;


?>
