<?php

session_start();


    $mail=$_SESSION["email"];
$id=$_SESSION["id"];
$camp_id=$_GET['camp_id'];

 ?>

<html>

<head>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
<link rel="stylesheet" href="https://res.cloudinary.com/heptera/raw/upload/v1643115380/files/time_picker/simple_picker_l588ar.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<style type="text/css">

body{
	font-family: 'lato';
}

img.icon-img-of-usr {
    height: 28px;
    border-radius: 100px;
    margin-right: 10px;
}
a{
	text-decoration: none;
}

.name-of-usr {
    font-size: 12px;
    padding: 5px;
    color: white;
    height: fit-content;
    display: inline-block;
    white-space: nowrap;
    overflow: hidden !important;
    text-overflow: ellipsis;
    width: 140px;
    }

.dropdown-toggle::after{
	display: none;
}

.btn-heght{
	font-size: 12px;
    padding: 7px;
    color:black;
    text-decoration: none;
}

.head-of-ab {
    padding: 10px;
    border-bottom: 1px solid #f2f2f2;
}

.main-con-of-all-type{

    padding: 40px;

}
.con-of-ab_type.container {
    height: calc(100vh - 110px);
    overflow: scroll;
}

.con-of-ab_type::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.con-of-ab_type {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}
.card.crd-of-ab {
    border-radius: 30px;
    margin: auto;
     margin-top: 40px;
    box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
    }

    img.card-img-top.crd-of-ab-img {
    border-radius: 30px;
    padding: 20px;
}

.card.crd-of-ab {
    border-radius: 30px;
    }
    img.card-img-top.crd-of-ab-img {
    border-radius: 30px;
    padding: 20px;
}

.card-body.crd-opt-of-ab {
    border-top: 1px solid #f2f2f2;
    padding: 20px;
    }

    .ab-opt-con-all {

    border-radius: 30px;

    width: 100%;
    display: inline-flex;

}

.card-link.crd-otp-act {
    width: 50%;
    text-align: center;
    font-size: 12px;
    padding: 10px;
    border-radius: 30px;

}

.crd-otp-act:hover{

cursor: pointer;
background: #4155a214;
color: white !important;
}

button.btn-of-thm {
    margin: auto;
    background: black;
    color: white;
    border-radius: 10px;
    padding: 6px 15px;
    font-size: 12px;
    }

    .con-of-btn-that-add {
    width: fit-content;
    margin: auto;
}
.dropdown-menu .dropdown-item {
    padding: 0.5rem 1rem;
    font-size: 13px;
    font-weight: 600;
	}
	.dropdown-menu.show {
    border-radius: 10px !important;
		border: none;

	}
	button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
	}
	.dropdown-item:hover {
    cursor: pointer;
	}
	.dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
	}

	.dropdown-item {
    border-radius: 10px;
	}



.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {

  height: min-content;
  text-align: center;

  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;

  margin: auto;
}


.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 24px;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
    position: relative;
    display: flex;
    text-align: center;
    color: #504b4b;
  }
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}




label.label-of-mdl {
    font-size: 12px;
    color: black;
    margin-top: 10px;
		margin-bottom: 0.5rem;
  }

  span.badge-of-list-name {
    font-size: 12px;
    background: black;
    padding: 3px 20px;
    border-radius: 20px;
    color: white;
  }
  span.badge-of-list-name.spn-blue {
    background: #0000ff1c;
    color: blue;
  }

  span.badge-of-list-name.spn-green {
    color: green;
    background: #0080002b;
  }

  span.badge-of-list-name.spn-pink {
    color: #cf0f31;
    background: #ed294b38;
  }

  span.badge-of-list-name.spn-vio {
    color: #bf1abf;
    background: #eb27eb30;
  }

  .con-of-temp-con {
    width: 50%;
  }


  .body_of_camp_det {
    width: 49%;
    display: inline-block;
  }

  .main-con-of-camp-data {
    width: 100%;
    display: inline-flex;
}
.auta-main-dis-dash {
    width: 240px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
    margin: auto;
    margin-bottom: 10px;
  }

  .main-con-img-temp {
    flex: auto;
    min-height: 216px;
    display: inline-grid;
    width: 100%;
    background-size: cover;
    border-radius: 5px;
  }

.prev_btn_dsg_trg:hover {
    background: rgb(2, 80, 65);
    color: white;
    cursor: pointer;
}

.auta-main-dis-dash.sel_temp_in_db.active_temp_sel {
    outline: 3px solid blue;
}

span.bdg-tp-btn {
	margin-left: auto;
	font-size: 12px;
	background: rgb(245, 249, 248);
	padding: 2px 10px;
	border-radius: 10px;
	color: rgb(2, 80, 65);
	font-family: 'Lato';
	font-weight: 600;
	letter-spacing: .4px;
	height: fit-content;
}
.auta-main-dis-dash {
    width: 240px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
    margin: auto;
    margin-bottom: 10px;
	}
	.main-con-img-temp {
    flex: auto;
    min-height: 216px;
    display: inline-grid;
    width: 100%;
    background-size: cover;
    border-radius: 5px;
	}
	.head-line-of-mdl h4 {
    color: black;
    margin-bottom: 1.5rem;
    font-size: 0.9375rem;
	}
	.crd-of-ab-img{
		cursor: pointer;
	}

	.head-of-modal-2 {
    width: 100%;
    padding: 20px;
    color: black;
	}
	.head-of-modal-2 h2 {
    font-size: 14px;
    margin-bottom: 0px;
	}

	button.btn-blck-non-fcs {
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
	}
	.btn-blck-in-auta-fcs {
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
	}
	.btn-blck-non-fcs:hover {
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
	}
	.btn-blck-in-auta-fcs:hover {
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
	}
	div#modal-con-of-temp-pre {
	    height: calc(80vh - 122px);
	    padding: 20px;
	    overflow: scroll;

		}
		.con-of-cnt-data.com-for-lnk {
    padding: 6px;
    width: 100%;
    background: #f2f2f2;
    margin-top: 10px;
    text-align: center;
    border-radius: 10px;
	}
	.active-temp{
		outline: 3px solid blue;
	}

	.ip-by-def-dsg {
		width: 100%;
    background-color: #FFFFFF;
    height: 36px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 10px;

    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;
	}
	div#more_confige_for_sendr {
    padding-top: 10px;
	}

	.ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
	}

	.ip-field-of-day {
	    display: inline-block;
	    vertical-align: top;
	    width: 100%;
	    background-color: #f9f9f9;
	    padding: 7.5px 7.5px 3.75px;
	    border: 1px solid #ddd;
	    border-radius: 2.5px;
	    font-size: 14px;
	    min-height: 44px;
	    overflow: hidden;
	    width: 60px;
	    border-radius: 20px;
	    margin-bottom: 10px;
	    margin-right: 5px;
		}
		.ent-num-of-con-send-per-lst{
			padding: 0px;
		}
	.con-of-modal-2.row {
    width: 100%;
    padding: 20px;
	}
	label.lbl-of-modal-ip {
    padding: 0px;
    font-size: 12px;
    font-weight: 500;
    color: black;
		padding: 0px;
    font-size: 12px;
    font-weight: 500;
    color: black;
    font-size: 12px;
    padding-bottom: 10px;
    padding-left: 5px;
    padding-top: 10px;

	}
	.note-for-ip-def {
    font-size: 12px;
    font-weight: 500;
    padding-left: 5px;
	}
	div#send_id_con{
		padding: 0px;
	}
	#smtp_serv_data{
		padding: 0px;
	}
	div#send_reply_con{
		padding: 0px;
}

button.btn.btn-link.btn-heght.btn-shed-camp-test {
    background: #0e0006;
    color: white;
    border-radius: 10px;

	}

	button.btn.btn-link.btn-heght {
    margin-right: 10px;
	}
	.cp-round:after{
        border-top: solid 3px #564f4e;


    }

		.card.crd-of-ab.err_in_test {
    outline: 3px solid red;
	}

	.choices__inner {
	 border-radius: 20px !important;
 }
.choices{
 margin-bottom: 0px !important;
}
 .choices__list--dropdown {
	 border-radius: 20px !important;
	 margin-top: 10px !important;
 }
 .choices{

	 padding: 0px;
	 margin-bottom: 8px !important;

 }

 .con_of_sel_data_seg {
     display: none;
		 padding: 0px;
	 }

	 button#sel_time_for_camp {
    margin-bottom: 10px;
    width: 300px;
    margin-left: 5px;
	}
	.simplepicker-day-header {
    color: #fff;
    background-color: #016565;
    text-align: center;
    padding: 4px 0;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }

  .simpilepicker-date-picker {
    width: 326px;
    cursor: auto;
    font-family: Verdana,Geneva,Tahoma,sans-serif;
    font-size: 14px;
    background-color: #fff;
    margin: 5% auto;
    box-shadow: 1px 2px 4px 0.5px rgba(0,0,0,.22), 1px 2px 4px 0.5px transparent;
    border-radius: 10px;

  }
.simplepicker-wrapper.active{
	z-index: 1000000 !important;

}
div#held_ver_data_of_camp {
	 padding: 10px 0px;
	 font-weight: 500;
	 color: green;

 }


button.simplepicker-btn {
    border-radius: 10px;
	}

	div#held_ver_data_of_camp{
		padding-left: 5px;
	}
	</style>


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
</head>

<body>

<div class='main-content'>

<div class="head-of-ab">

	<button type="button" class="btn btn-link btn-heght com-for-lnk" data-for-serv="1" data-path-ses="dashboard/" data-target-link="https://dashboard.auftera.com/dashboard/">

		Back To dashboard</button>
<div class="dropdown" style="float:right">
  <a class=" dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    <div class="media-body ml-2 d-none d-lg-block" style="
    padding: 3px;
    background: black;
    border-radius: 100px;
    display: inline-flex !important;
    margin-left: 0px !important;
">
<img class="icon-img-of-usr" src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg"><div class="name-of-usr" style="
">
<?php echo $mail;?></div>
<img src="https://res.cloudinary.com/heptera/image/upload/v1633623939/ab_test/arrow_drop_down_white_24dp_twuibj.svg" style="
    padding-right: 10px;
"></div>
  </a>
	<div class="dropdown-menu dropdown-menu-right" style="
    width: 100%;
    margin-top: 5px !important;
">
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/">
<span class="padding-left:10px;">
Manage List </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="studio/" data-target-link="https://studio.auftera.com/studio/">
<span class="padding-left:10px;">
Studio</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/">
<span class="padding-left:10px;">
Template</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="automation/" data-target-link="https://automation.auftera.com/automation/">
<span class="padding-left:10px;">
Automation</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="campign/" data-target-link="https://campign.auftera.com/campign/">
<span class="padding-left:10px;">
Campign</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/">
<span class="padding-left:10px;">
Social Marketing</span></button>
<div class="dropdown-divider"></div>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="http://account.auftera.com/account/plan/recent/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Plan</span></button>
<button class="dropdown-item  com-for-lnk" data-path-ses="account/" data-for-serv="1" data-target-link="http://account.auftera.com/account/confige/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor"></path><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Log Out</span></button>
</div>
</div>

</div>

<script>



id='<?php echo $id;?>';
email='<?php echo $mail;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})

</script>

<div class="con-of-ab_type container">


<div class="main-con-of-all-type row" id="conn-of-ab-test-hold">





</div>

<div class="con-of-btn-that-add">


<button class="btn-of-new-add btn-of-thm" id="new-test-add">Add New Test Type</button>

</div>


	</div>

	<div class="head-of-ab" style="border-top: 1px solid #f2f2f2;border-bottom:0px;text-align: right;">

	<button type="button" class="btn btn-link btn-heght" id="enter_save_name_of_ab">

		Save</button>
  <button type="button" class="btn btn-link btn-heght btn-shed-camp-test" id="shed_camp_final_btn">

		Sheduled Campign</button>


</div>

</div>


<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>





<div class="modal-2"  id='sel-temp-modal-chs'>
<article class="content-wrapper" style="width: 65%;
    height: 80vh;padding:0px;">

<div class="head-of-modal-2"><h2>Select Template</h2></div>
<div class="con-of-modal-2 row" id="modal-con-of-temp-pre"></div>
<div class="modal-footer" style="
    width: 100%;
">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" onclick="modalclose('#sel-temp-modal-chs')">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="select_temp_for_camp_test">Select Template </button>
</div>
</article>
</div>




<div class="modal-2"  id='modal-to-sel-sub-and-prev'>
<article class="content-wrapper" style="padding:0px;">

<div class="head-of-modal-2"><h2>Enter test Configuration</h2></div>
<div class="con-of-modal-2 row" >
<label class="lbl-of-modal-ip" >Enter Subject Line</label>
<input type="text" class="ip-by-def-dsg" id="sub_ip_fld"  placeholder="Enter Subject Line">
<label class="lbl-of-modal-ip" >Enter Preveiw Text</label>
<input type="text" class="ip-by-def-dsg" id="pre_ip_fld"  placeholder="Enter Subject Line">
<label class="lbl-of-modal-ip" >Enter Unsibscribe Link</label>
<input type="text" class="ip-by-def-dsg" id="ent-un-sub-link"  placeholder="Enter Subject Line">
<label class="lbl-of-modal-ip">Select Sender Profile</label>
<div id='send_id_con'>
<div class="cp-spinner cp-round"></div>
</div>

<label class="lbl-of-modal-ip">Reply Profile</label>
<div id='send_reply_con'>
<div class="cp-spinner cp-round"></div>
</div>
<label class="lbl-of-modal-ip">Select SMTP Server</label>

<div id="smtp_serv_data">
</div>

</div>
<div class="modal-footer" style="
    width: 100%;
">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" onclick="modalclose('#modal-to-sel-sub-and-prev')" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="set-temp-configuration-set">Select Template </button>
</div>
</article>
</div>




<div class="modal-2"  id='sel-temp-modal-chs'>
<article class="content-wrapper" style="width: 65%;
    height: 80vh;padding:0px;">

<div class="head-of-modal-2"><h2>Select Template</h2></div>
<div class="con-of-modal-2 row" id="modal-con-of-temp-pre"></div>
<div class="modal-footer" style="
    width: 100%;
">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" onclick="modalclose('#sel-temp-modal-chs')">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="select_temp_for_camp_test">Select Template </button>
</div>
</article>
</div>




<div class="modal-2"  id='modal-ent-test-name-ab'>
<article class="content-wrapper" style="padding:0px;">

<div class="head-of-modal-2"><h2>Enter test Name</h2></div>
<div class="con-of-modal-2 row" >
	<label class="lbl-of-modal-ip" >Enter A/B test Name</label>
	<input type="text" class="ip-by-def-dsg" id="test_name_save_ab_fl"  placeholder="Enter Test Name">

</div>
<div class="modal-footer" style="
    width: 100%;
">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" onclick="modalclose('#modal-ent-test-name-ab')" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="sub-test-name-save-fl">Save</button>
</div>
</article>
</div>



<div class="modal-2"  id='modal-to-sel-list-data'>
<article class="content-wrapper" style="padding:0px;">

<div class="head-of-modal-2"><h2>Enter Contact List For Test</h2></div>
<div class="con-of-modal-2 row" >
	<div class="sel-basic-list">
<label class="lbl-of-modal-ip">Enter Subject Line</label>
<div class="sel_data-of-aud_id" style="padding:0px;"></div>

<label class="lbl-of-modal-ip">Enter Subject Line</label><br>
<select class="sel_des_of_opt" id="sel_opt_tp_chg">
<optgroup label="All Subscriber"> <option value="all_sub">All Subscriber</option></optgroup>
<optgroup label="For Tag">
<option value="tag">tag</option></optgroup>
<optgroup label="For Segment"> <option value="segment">Segment</option></optgroup>
<optgroup label="Pre Built Segment">
<option value="new_sub">New Subscriber</option>
<option value="act_sub">Active Subscriber</option>
<option value="inact_sub">Inactive Subscriber</option>
</optgroup>
</select>

<div class="con_of_sel_data_seg"></div>
<div class="ent-num-of-con-send-per-lst">
<label class="lbl-of-modal-ip">Per List Test Send</label><br>
<input class="ip-field-of-day" id="per_contact_test_send" placeholder="500" >
<div class="note-for-ip-def">Enter number of contact that will send for test and after decide what is best Minimum contact 500 required</div>
</div>
</div>
</div>
<div class="modal-footer" style="
    width: 100%;
">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" onclick="modalclose('#modal-to-sel-list-data')" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="set-list-data-of-con">Select Time Params </button>
</div>
</article>
</div>



<div class="modal-2"  id='modal-sel-res-part'>
<article class="content-wrapper" style="padding:0px;">

<div class="head-of-modal-2"><h2>Enter test Configuration</h2></div>
<div class="con-of-modal-2 row" style="

    display: block;
">

    <label class="lbl-of-modal-ip">Select Time For Test Sheduled</label><button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="sel_time_for_camp">Select Time Period For Test </button>

<div id="held_ver_data_of_camp"></div>
<div class="note-for-ip-def">Enter number of contact that will send for test and after decide what is best Minimum contact 500 required</div>



     <label class="lbl-of-modal-ip">Select Time Period for React</label>


		 <select class="sel_des_of_opt" id="sel_opt_for_res_react">
	 	<optgroup label="After time To Result Sheduled" id="react-time-arr-app">

	 	</optgroup>


	 	</select>

<div class="note-for-ip-def">Enter Time duration for sheduled result campign after selected test sheduled time.</div>
  <label class="lbl-of-modal-ip">Which Parameter to trigger Result</label>
	<select class="sel_des_of_opt" id="sel_opt_for_res">
	<optgroup label="Select Who Get Best">
		<option value=">1">Open</option>
		<option value=">2">Click</option>
	</optgroup>


	</select>

	<div class="note-for-ip-def">Enter Conditon type for sheduled result campign like open,click and reply. we prefer as per your campign targeted action.</div>


</div>
<div class="modal-footer" style="
    width: 100%;
">
<button type="button" class="btn btn-secondary btn-blck-non-fcs" onclick="modalclose('#modal-sel-res-part')" data-dismiss="modal">Back</button>
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="sel_data_for_shed_camp">Sheduled Test Now </button>
</div>
</article>
</div>








</body>
</html>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>
<script src="https://res.cloudinary.com/heptera/raw/upload/v1643115415/files/time_picker/time_picker_vz4zwv.js"></script>
<script type="text/javascript">

usr_id="<?php echo $id;?>";
camp_id='<?php echo $camp_id;?>';
id_of_temp_new=0;
id_of_selected_camp_test="";


name_of_a_b_test="";
error_code_of_check={'temp-id-of-test':"Select template For this Test",'sub-of-ml-sel':"Add Subject Line",'prev-of-ml-sel':"Add Preview Text",'sender-data-od-send':"Select Sender data",'smtp-data-send':"Select Valid SMTP Server",'reply-id':"Select Valid Reply",'suficient_test':"Set Suficient test",'success':"Succesfully Verified","un-sub-link-temp":"Please Select Unsubscribe Link"};

arr_of_react_cnt=[4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34]

tag_get=[];
email_list_arr=[];
ip_for_test_con_send=0;
def_ab_test_name_glob="";

val_of_react_type_shed="";
time_data="";
final_react_time="";
react_type_of_shed="";
final_name_for_db_usd="";
filt_json_data={};

function validate_last_step_for_shed(){


err_flg=0;

if(time_data==0){
err_msg_data("Select Valid Time Date");
err_flg=1;
}

val_of_react_time=$("#sel_opt_for_res_react").val();

if(val_of_react_time==null){
err_msg_data("Select Valid React Time");
err_flg=1;
}else{
final_react_time=val_of_react_time;
}

val_of_react_type_shed=$("#sel_opt_for_res").val();

if(val_of_react_type_shed==null){
err_msg_data("Select Type Of Condition");
err_flg=1;
}else{
react_type_of_shed=val_of_react_type_shed;
}


if(err_flg){
	return 0;
}else{
	return 1;
}

}


function init_data_of_temp_db_url(temp_id,db_id,unsub_link,sub_name){

res_flg_mes=0;

	$.ajax({
			url : "https://campign.auftera.com/campign/ajaxfile/crt-camp/set_temp_data_in_db_url.php",
			type: 'POST',
			data : {camp_id:db_id,subject:sub_name,red_url_un:unsub_link,temp_id:temp_id}
		}).done(function(response){



})


}

function init_data_in_db_temp(temp_name,mail_sub,mail_pre,sender_id,smtp_id,con_id,reply_id){


	$.ajax({
			url : "https://campign.auftera.com/campign/ajaxfile/crt-camp/save_content_data.php",
			type: 'POST',
			data : {temp_name:temp_name,mail_sub:mail_sub,mail_pre:mail_pre,sender_id:sender_id,smtp_id:smtp_id,con_id:con_id,reply_id:reply_id}
		}).done(function(response){

console.log(response);

	})


}

function init_data_in_db_list(id_of_test,camp_con_id){

que_data={"type_seq":"linear","arr_of_att":[ip_for_test_con_send]};

list_id=JSON.stringify(tag_get);

if(id_of_test=="result"){

que_data['arr_of_att'][0]=20000;
}
filt_data=JSON.stringify(filt_json_data);

que_data=JSON.stringify(que_data);
ptr=0;



$.ajax({
		url : "https://campign.auftera.com/campign/ajaxfile/crt-camp/save_lst_data.php",
		type: 'POST',
		data : {merge_fld:"",list_data:list_id,filt_opt:filt_data,con_id:camp_con_id,que_data:que_data,ptr:ptr}
	}).done(function(response){

console.log(response);
	});

}
function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}


function add_hour_time(date,time_period){

var dt = new Date(date);
dt.setHours( dt.getHours() + parseInt(time_period) );


arr_of_dt=dt.toString().split(" ");

str_of_date="";
for(i=0;i<5;i++){

str_of_date+=" "+arr_of_dt[i];
}

return str_of_date;

}

function init_time_shed_det(id_of_camp,time_shed){

list_id=JSON.stringify(tag_get);

	$.ajax({
			url : "https://campign.auftera.com/campign/ajaxfile/crt-camp/save_camp_shed_time.php",
			type: 'POST',
			data : {camp_id:id_of_camp,lst_dt:list_id,time_data:time_shed,usr_id:usr_id}
		}).done(function(response){

	console.log(response);
		});
}
function init_data_of_content_in_db(id_of_test,db_id_for_test,test_name_def){


console.log(db_id_for_test);
sel_of_attr_modal_nm='[id-of-test-attr="'+id_of_test+'"]';

temp_id_of_temp=$(sel_of_attr_modal_nm).attr("temp-id-of-test");
unsub_link_for_temp=$(sel_of_attr_modal_nm).attr("un-sub-link-temp");
subject_line_of_test=$(sel_of_attr_modal_nm).attr("sub-of-ml-sel");
prev_btn_of_test=$(sel_of_attr_modal_nm).attr("prev-of-ml-sel");

if(id_of_test=="result"){

send_id_temp=JSON.stringify({"ab_best_type":val_of_react_type_shed,"test_name":test_name_def});
temp_id_of_temp="result";
time_data=add_hour_time(time_data,final_react_time);
}else{
send_id_temp=$(sel_of_attr_modal_nm).attr("sender-data-od-send");
}
smtp_id_for_temp=$(sel_of_attr_modal_nm).attr("smtp-data-send");
reply_id_temp=$(sel_of_attr_modal_nm).attr("reply-id");



console.log(time_data);

init_data_of_temp_db_url(temp_id_of_temp,db_id_for_test,unsub_link_for_temp,subject_line_of_test)

init_data_in_db_temp(temp_id_of_temp,subject_line_of_test,prev_btn_of_test,send_id_temp,smtp_id_for_temp,db_id_for_test,reply_id_temp);


init_data_in_db_list(id_of_test,db_id_for_test);
init_time_shed_det(db_id_for_test,time_data);



}
function init_post_data_for_name(camp_name_test_def,id_of_temp_def){

res_flg=0;


console.log(camp_name_test_def+"^"+id_of_temp_def);
	$.ajax({
			url : "https://campign.auftera.com/campign/ajaxfile/crt-camp/save_camp_name.php",
			type: 'POST',
			data : {usr_id:usr_id,camp_name:camp_name_test_def+"^"+id_of_temp_def,old_name:"newcampigns"}
		}).done(function(response){

json_parsed_res=JSON.parse(response);

console.log(json_parsed_res);


if(json_parsed_res.status==1){


init_data_of_content_in_db(id_of_temp_def,json_parsed_res.message,camp_name_test_def);
}else{



}

res_flg=1;
		})


	if(res_flg){
		return 1;
	}

}

function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

function shed_test_name_in_db_only(){

$(".crd-of-ab").map(function(){

id_of_temp_def=$(this).attr("id-of-test-attr");


init_post_data_for_name(final_name_for_db_usd,id_of_temp_def);


sleep(2000);

})

sleep(2000);

init_post_data_for_name(final_name_for_db_usd,"result");
}
$(document).on('click','#sel_data_for_shed_camp',function(){

if(validate_last_step_for_shed()){

err_msg_data("Valid function");

shed_test_name_in_db_only();

}else{
	err_msg_data("function not validate");
}


})


function valid_of_data_save_in_fl(){



name_of_a_b_test=$("#test_name_save_ab_fl").val();

console.log(name_of_a_b_test);
if(name_of_a_b_test!=undefined || def_ab_test_name_glob.length>0){
append_load_in_all_btn('#sub-test-name-save-fl');

	ab_file_data_test=$("#conn-of-ab-test-hold").html();

		$.ajax({
				url : "./ajaxfile/save_ab_in_file.php",
				type: 'POST',
				data : {data_of_post:ab_file_data_test,name_of_fl_ab:name_of_a_b_test,file_name_set:def_ab_test_name_glob}
			}).done(function(response){

err_msg_data("Test Has Been Saved");
append_txt_of_lds('#sub-test-name-save-fl');
modalclose("#modal-ent-test-name-ab");
json_prsh=JSON.parse(response);
if(window.location.href.search("#")>0){


}else{
window.location.href =window.location.href+"#"+json_prsh['message'];

}
			})
}else{
	err_msg_data("A/B test name must be 10 character");
}

}


$(document).on('click','#sub-test-name-save-fl',function(){

valid_of_data_save_in_fl();

})

$(document).on('click','#enter_save_name_of_ab',function(){

console.log(def_ab_test_name_glob);
if(	def_ab_test_name_glob.length==0){
modalEvent("modal-ent-test-name-ab");
}else{
	valid_of_data_save_in_fl();
}
})

function init_file_from_ab_test_save(fl_name){


final_name_for_db_usd=atob(fl_name).split("^")[1];

console.log(final_name_for_db_usd);
	$.get("./saved_ab/"+fl_name+".html?data_fld="+Date.now(), function(data, status){

		console.log(data);
	   $("#conn-of-ab-test-hold").html(data);
	  });

}


function init_menu_of_react_time_arr(){

str_app="";

for(const val of arr_of_react_cnt){

str_app+='<option value="'+val+'">'+val+' hours</option>';

}


$("#react-time-arr-app").html(str_app);

init_sel_menu("#sel_opt_for_res_react");

}


$(document).ready(function(){


name_of_ab_test_def=window.location.href.split("#");

if(name_of_ab_test_def.length>1){

	def_ab_test_name_glob=name_of_ab_test_def[1];

	init_file_from_ab_test_save(def_ab_test_name_glob);
}
init_sel_menu("#sel_opt_tp_chg");

init_sel_menu("#sel_opt_for_res");


init_menu_of_react_time_arr();

})

let simplepicker = new SimplePicker({
      zIndex: 10
    });

		simplepicker.on('submit', (date, readableDate) => {
console.log(readableDate);
		      val_time_dt(readableDate);

		    });

				function val_time_dt(time_date_val){




				$.ajax({
				    url : "https://campign.auftera.com/campign/ajaxfile/crt-camp/date_val_for_crt_camp.php",
				    type: 'POST',
				    data : {ip_for_time_sel_camp:time_date_val,usr_id:usr_id}
				  }).done(function(response){ //
				   console.log(response);

				  if(response==1){

				$("#held_ver_data_of_camp").html(time_date_val);

				$("#held_ver_data_of_camp").css('color',"green");


				time_data=time_date_val;

				  }else{
	time_data=0;
				    $("#held_ver_data_of_camp").html("please select valid date");
				    $("#held_ver_data_of_camp").css('color',"red");
				  }

				  });


				}



$(document).on("click","#sel_time_for_camp",function(){

simplepicker.open();

    })



function validate_val_of_shed_list(){
flg_val_fld=0;

tag_get=$("#sel_of_list_aud").val();
val_field_dt=$("#sel_opt_tp_chg").val();
tag_get_seg_data=$("#ele_of_seg_sel").val();

console.log(tag_get_seg_data);
	if(tag_get.length!=0){


email_list_arr=tag_get;






if(val_field_dt=="tag" || val_field_dt=="segment"){



if(tag_get_seg_data==null){



err_msg_data("Select Contact Field");

  flg_val_fld=1;


}else{


filt_json_data["name"]=val_field_dt;
  filt_json_data["data"]=tag_get_seg_data;
}

}else if(val_field_dt=="all_sub"){


filt_json_data["name"]=val_field_dt;

}else{

	err_msg_data("Select Type Of contact");
  flg_val_fld=1;

}

}else{
err_msg_data("Select Audiance List");
flg_val_fld=1;
}

if(flg_val_fld==0){

ip_for_test_con_send=$("#per_contact_test_send").val();

if(ip_for_test_con_send>499){

	return 1;
}else{

	err_msg_data("Enter Valid Minimum contact 500");
	return 0;
}

}else{
	return 0;
}

}


$(document).on('click','#set-list-data-of-con',function(){

if(validate_val_of_shed_list()){

modalEvent("modal-sel-res-part");

}


})




$(document).on('change',"#sel_opt_tp_chg",function(){

val_of_opt=$(this).val();

$(".con_of_sel_data_seg").empty();


if(val_of_opt=="segment"){
get_seg_data("");

$(".con_of_sel_data_seg").html('<label class="lbl-of-modal-ip">Select Field</label><br><span class="autocomplete-select-seg"></span>');

}else if(val_of_opt=="tag"){

get_tag_data("");

$(".con_of_sel_data_seg").html('<label class="lbl-of-modal-ip">Select Field</label><br><span class="autocomplete-select-seg"></span>');
}

$(".con_of_sel_data_seg").css("display","block");

});



function get_seg_data(data_flg){

//console.log(tag_get);

//pres_lst_jsn=JSON.stringify(tag_get);


$.ajax({
  type: "POST",
  url: "./ajaxfile/get_seg_acc_list.php"

}).done(function(response1) {



        console.log(response1);

get_init_auto_comp_seg_data("",response1);



});


}


function get_tag_data(){

//pres_lst_jsn=JSON.stringify(pres_lst_ele);

//console.log(pres_lst_jsn);

$.ajax({
  type: "POST",
  url: "./ajaxfile/get_tag_data_lst.php"

}).done(function(response1) {



get_init_auto_comp_seg_data("",response1);


});


}




function get_init_auto_comp_seg_data(data_id_con,data){




tag_get_seg_data=[];
json = JSON.parse(data);

str_sel_ele="<select id='ele_of_seg_sel'>";

for(i=0;i<json.length;i++){

	val_jsn=json[i]['value'];
	val_lab=json[i]['label'];
	str_sel_ele+='<option value="'+val_jsn+'">'+val_lab+'</option>';

}

str_sel_ele+='<select>';

$(".con_of_sel_data_seg").append(str_sel_ele);

init_sel_menu("#ele_of_seg_sel");

}



function init_sel_menu(sel_of_que){

var multipleCancelButton = new Choices(sel_of_que, {
removeItemButton: true,
maxItemCount:5,
searchResultLimit:10,
renderChoiceLimit:0
});




}




function get_init_auto_comp_data(data_id_con,data){


console.log(data);

str_of_app='<select id="sel_of_list_aud" placeholder="Select upto 5 Lists" multiple>';
for(const val of data){

str_of_app+='<option value="'+val.value+'">'+val.label+'</option>';

}

str_of_app+='</select>';

$('.sel_data-of-aud_id').html(str_of_app);

init_sel_menu("#sel_of_list_aud");
}



function get_aud_data(){



$.ajax({
  type: "POST",
  url: "./ajaxfile/get_list_of_id.php"

}).done(function(response1) {

console.log(response1);
        get_init_auto_comp_data("autocomplete-select",JSON.parse(response1));


    get_list_val(response1);


/*
get_seg_data("");
*/
});


}

function get_list_val(json_data_to_lst){

ret_arr=[];
lst_dt=JSON.parse(json_data_to_lst);

console.log(lst_dt);

for (var i = 0; i < lst_dt.length; i++) {

ret_arr.push(lst_dt[i]['value']);


};

pres_lst_ele=ret_arr;

}



function remove_err_code(){

setTimeout(function(){



	$(".crd-of-ab").map(function(){

      $(this).removeClass("err_in_test");

	})
 }, 2000);

}

data_of_content=[];

function init_con_of_data_in_arr(target){


console.log(target);
loc_arr={};

loc_arr.temp_id=$(target).attr("temp-id-of-test");
loc_arr.sub_fld=$(target).attr("sub-of-ml-sel");
loc_arr.prev_fld=$(target).attr("prev-of-ml-sel");
loc_arr.sender_id=$(target).attr("sender-data-od-send");
loc_arr.smtp_id=$(target).attr("smtp-data-send");
loc_arr.reply_id=$(target).attr("reply-id");

data_of_content.push(loc_arr);



}
function valid_ab_test_camp_desg(){

check_attr_of_template=['temp-id-of-test','sub-of-ml-sel','prev-of-ml-sel','sender-data-od-send','smtp-data-send','reply-id','un-sub-link-temp'];



count_of_all_test=0;
err_cnt=0;
$(".crd-of-ab").map(function(){

count_of_all_test=count_of_all_test+1;

	loc_err=0;
for(const val of check_attr_of_template){

val_of_attr=$(this).attr(val);

console.log(val_of_attr);
if(val_of_attr==undefined){
	err_msg_data(error_code_of_check[val]);
	remove_err_code();
	$(this).addClass("err_in_test");
	loc_err=+1;
err_cnt=+1;
break;
}


}


if(loc_err==0){
	init_con_of_data_in_arr(this);
}

})

console.log(count_of_all_test);
if(err_cnt==0){

	if(count_of_all_test>=2){
	err_msg_data(error_code_of_check['success']);

	console.log(data_of_content);
	return 1;
}else{
	err_msg_data(error_code_of_check['suficient_test']);
	return 0;
}
}else{



return 0;

}


}



$(document).on('click','#shed_camp_final_btn',function(){

console.log(valid_ab_test_camp_desg());

if(valid_ab_test_camp_desg()){
get_aud_data();
modalEvent("modal-to-sel-list-data");

}

})


function init_field_in_sel_test(type,val){

console.log(id_of_selected_camp_test);
$('[id-of-test-attr="'+id_of_selected_camp_test+'"]').attr(type,val);
}
function validURL(str) {
  var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
  return !!pattern.test(str);
}


function val_step_2(){

sub_of_mail=$("#sub_ip_fld").val();

console.log(sub_of_mail);

init_field_in_sel_test("sub-of-ml-sel",sub_of_mail);

if(!(sub_of_mail.length>0)){

 err_msg_data("Enter Subject Of Mail.");


  return 0;
}


pre_of_mail=$("#pre_ip_fld").val();

init_field_in_sel_test("prev-of-ml-sel",pre_of_mail);

if(!(pre_of_mail.length>0)){



err_msg_data("Enter Preview Of Mail For Recognize by Your User.");


return 0;

}




if($("#smtp_sel_id").val()==null){

	err_msg_data("Please Select SMTP Server");
return 0;

}



send_mail=$("#send_id_con").children("select").val();


reply_id=$("#send_reply_con").children("select").val();

un_sub_link=$("#ent-un-sub-link").val();


if(!validURL(un_sub_link)){

	err_msg_data("Please Enter Valid Unsubscribe Link");
return 0;
}else{

init_field_in_sel_test("un-sub-link-temp",un_sub_link);
}
obj_of_send_profile={};

if(send_mail==null){

err_msg_data("Please Select Sender Profile");
return 0;
}else{

	if(reply_id==null){

		err_msg_data("Please Select Reply Profile");
return 0;
	}else{

	if(isEmail($("#chg_trg_of_pro option:selected").html())){
obj_of_send_profile.sender_id=send_mail;
val_of_from_profile=$("#more_confige_for_sendr").children("#from_name_fro_sender").val();


obj_of_send_profile.sender_name=val_of_from_profile;
obj_of_send_profile.tp_name="email";
	}else{
		obj_of_send_profile.sender_id=send_mail;


		val_of_from_profile=$("#more_confige_for_sendr").children("#from_name_fro_sender").val();

		obj_of_send_profile.sender_name=val_of_from_profile;


		cust_email_name_pro=$("#more_confige_for_sendr").children("#init_sender_profile").children("#domain_email_pro").val();


		if(cust_email_name_pro=="email" || cust_email_name_pro.length==0){

err_msg_data("Eneter Valid Email Profile");
return 0;
}else{
	obj_of_send_profile.tp_name=cust_email_name_pro;
		}
	}


	if(obj_of_send_profile.sender_name.length==0){

		err_msg_data("Enter Sender name");
return 0;
	}
	console.log(obj_of_send_profile);

	}
}
send_mail=JSON.stringify(obj_of_send_profile);

init_field_in_sel_test("sender-data-od-send",send_mail);
smtp_id=$("#smtp_sel_id").val();


init_field_in_sel_test("reply-id",reply_id);
init_field_in_sel_test("smtp-data-send",smtp_id);
temp_def_name="";


return 1;
}




$(document).on('click','#set-temp-configuration-set',function(){

console.log(val_step_2());
if(val_step_2()){
err_msg_data("Set test Succesfully");
	modalclose("#modal-to-sel-sub-and-prev");
}else{

}



})


function str_of_smtp_data(data){



str_app='<select class="ip-by-def-dsg" id="smtp_sel_id">';


for (var i = 0; i < data.length; i++) {

 str_app+='<option value="'+data[i]['smtp_id']+'">'+data[i]['smtp_name']+'</option>'

};

str_app+='</select>';

return str_app;


}




function init_smtp_data(){





$.ajax({
  type: "POST",
  url: "./ajaxfile/get_all_smtp_server.php"

}).done(function(response1) {

console.log(response1);

data_of_send=JSON.parse(response1);

console.log(data_of_send);

str_of_app=str_of_smtp_data(data_of_send);

$("#smtp_serv_data").html(str_of_app);




});


}












function str_of_send_info(data){

str_app='<select class="ip-by-def-dsg" id="chg_trg_of_pro" class="frm_pro"><option disabled selected value> -- select an option -- </option>';

for (var i = 0; i < data.length; i++) {

 str_app+='<option value="'+data[i]['sender_id']+'">'+data[i]['email']+'</option>'

};

str_app+='</select>';

return str_app;


}


function str_of_rep_info(data){

str_app='<select class="ip-by-def-dsg" id="" class="frm_pro"><option disabled selected value> -- select an option -- </option>';
for (var i = 0; i < data.length; i++) {

if(data[i]['type']!="domain"){
 str_app+='<option value="'+data[i]['sender_id']+'">'+data[i]['email']+'</option>'
}
};

str_app+='</select>';

return str_app;




}


function  init_email_string(){


	$("#more_confige_for_sendr").remove();


	 $('<div id="more_confige_for_sendr"><input type="text" class="ip-by-def-dsg" id="from_name_fro_sender" placeholder="Enter From Name"  style="width:100%"></div>').insertAfter($("#chg_trg_of_pro"));
}

function init_domain_string(domain_name){


$("#more_confige_for_sendr").remove();

	$('<div id="more_confige_for_sendr"><div class="input-group mb-3" id="init_sender_profile" style="margin-bottom: 0px !important;"> <input type="text" class="ip-by-def-dsg  form-control" id="domain_email_pro" placeholder="Recipienti\'s username" aria-describedby="basic-addon2" style=" margin: 0px; "> <span class="input-group-text" id="mail_from_name_ext" style="border-top-left-radius: 0px; border-bottom-left-radius: 0px; padding: 0px 10px; border-top-right-radius: 10px; border-bottom-right-radius: 10px;">@'+domain_name+'</span> </div><input type="text" class="ip-by-def-dsg" id="from_name_fro_sender" placeholder="Enter From Name"  style="width:100%"></div>').insertAfter($("#chg_trg_of_pro"));
}
function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}


$(document).on('change','#chg_trg_of_pro',function(){

	data_of_opt=$("#chg_trg_of_pro option:selected").html();

if(isEmail(data_of_opt)){

	init_email_string();

}else{

init_domain_string(data_of_opt);
}

})

function init_sender_data(){





$.ajax({
  type: "POST",
  url: "./ajaxfile/get_all_sender_data.php"

}).done(function(response1) {


console.log(response1);
data_of_send=JSON.parse(response1);


str_of_app=str_of_send_info(data_of_send);

$("#send_id_con").html(str_of_app);

reply_str_app=str_of_rep_info(data_of_send);

$("#send_reply_con").html(reply_str_app);

init_smtp_data();
});


}



function check_max_limit(){
i=0;
$(".crd-of-ab").map(function(){
i=i+1;


})

if(i==4){
	return 0;
}else{
	return 1;
}

}

function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() *
 charactersLength));
   }
   return result;
}

function init_id_for_all_test(){



}
function add_tp_in_test(){
console.log(check_max_limit());

id_of_temp_new=makeid(4);
if(check_max_limit()){
	$('.main-con-of-all-type').append('<div class="card crd-of-ab" style="width: 18rem;" id-of-test-attr="'+id_of_temp_new+'" > <img src="https://res.cloudinary.com/heptera/image/upload/v1633595779/knowledge-base/campign/delete-camp/Screen_Shot_1943-07-15_at_2.05.26_PM_abopdn.png" class="card-img-top crd-of-ab-img open_temp_choose_trg" tp-of-modal-data="sel-temp-modal-chs" alt="..."> <div class="card-body crd-opt-of-ab"> <div class="ab-opt-con-all"> <div href="#" class="card-link crd-otp-act opn_detail_mdl" tp-of-modal-data="modal-to-sel-sub-and-prev"  id-of-test-attr="'+id_of_temp_new+'" ><img src="https://res.cloudinary.com/heptera/image/upload/v1633796984/ab_test/settings_suggest_black_24dp_tftyud.svg"/></div> <div href="#" class="card-link crd-otp-act del_btn_of_sel_dt" style="margin-left:0px;color:red"><img src="https://res.cloudinary.com/heptera/image/upload/v1633797035/ab_test/delete_sweep_black_24dp_1_ykjrtj.svg"></div> </div> </div> </div>');
	// body...
}else{

	err_msg_data("Maximum Limit Exceed Test");
}

}


$(document).on('click',".del_btn_of_sel_dt",function(){



$(this).parent(".ab-opt-con-all").parent(".crd-opt-of-ab").parent(".crd-of-ab").remove();

})





function temp_thumb(temp_id,temp_crt_date){



temp_dis_name=atob(temp_id.split("^")[1]);

var str_for_temp_res='<div class="auta-main-dis-dash temp_con" id="'+temp_id+'"> <div class="main-con-img-temp" style="background-image:url(https://scr.auftera.com/scr-api/?url=https://template.auftera.com/template/crt-template/crtedtemp/'+temp_id+'.html&amp;width=700&amp;height=800)"> <span class="bdg-tp-btn">'+temp_dis_name+'</span> </div> <div class="def_stat-of-dt"> <div class="con-of-cnt-data com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/edit/?temp_id='+temp_id+'">Edit</div>  </div> </div>';
$("#modal-con-of-temp-pre").append(str_for_temp_res);




}





function set_temp_data(){


$.ajax({
    url : './ajaxfile/get-all-temp.php',
    type: 'POST',
    data : {'id_to_get_data':usr_id}
  }).done(function(response){ //


console.log(response);

   var get_res_temp=JSON.parse(response);


$("#modal-con-of-temp-pre").empty();
 length_of_array=get_res_temp.length;

 if(length_of_array>0){
        for(i=0;i<length_of_array;i++){
temp_thumb(get_res_temp[i]['name'],get_res_temp[i]['dateofcrt']);


  }

    }else{




$("#modal-con-of-temp-pre").html('<div class="not-fd-temp-in-acc"> <svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" fill="currentColor" class="bi bi-diagram-3" viewBox="0 0 16 16" style=" color: #f2f2f2; "> <path fill-rule="evenodd" d="M6 3.5A1.5 1.5 0 0 1 7.5 2h1A1.5 1.5 0 0 1 10 3.5v1A1.5 1.5 0 0 1 8.5 6v1H14a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-1 0V8h-5v.5a.5.5 0 0 1-1 0V8h-5v.5a.5.5 0 0 1-1 0v-1A.5.5 0 0 1 2 7h5.5V6A1.5 1.5 0 0 1 6 4.5v-1zM8.5 5a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1zM0 11.5A1.5 1.5 0 0 1 1.5 10h1A1.5 1.5 0 0 1 4 11.5v1A1.5 1.5 0 0 1 2.5 14h-1A1.5 1.5 0 0 1 0 12.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm4.5.5A1.5 1.5 0 0 1 7.5 10h1a1.5 1.5 0 0 1 1.5 1.5v1A1.5 1.5 0 0 1 8.5 14h-1A1.5 1.5 0 0 1 6 12.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm4.5.5a1.5 1.5 0 0 1 1.5-1.5h1a1.5 1.5 0 0 1 1.5 1.5v1a1.5 1.5 0 0 1-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"></path> </svg><br> <span class="temp-not-fd-txt">In your account not found any template</span> <br><button type="button" class="btn-theme-dsg" id="next_temp_btn" style=" max-width: 200px; margin-top: 30px; height: inherit; padding: 10px; ">Create New Template<i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button> </div>');



    }

  });


}

function init_confige_modal_0(){

$("#sub_ip_fld").val("");
$("#pre_ip_fld").val("");

$("#send_id_con").html('<div class="cp-spinner cp-round"></div>');
$("#send_reply_con").html('<div class="cp-spinner cp-round"></div>');
$("#smtp_serv_data").html('<div class="cp-spinner cp-round"></div>');
}



$(document).on('click','.opn_detail_mdl',function(){
init_confige_modal_0();

id_of_selected_camp_test=$(this).attr("id-of-test-attr");

modal_eve=$(this).attr('tp-of-modal-data');

init_sender_data();
modalEvent(modal_eve);

})


$(document).on('click','.open_temp_choose_trg',function(){


id_of_selected_camp_test=$(this).parent("div").attr("id-of-test-attr");

set_temp_data();
modal_eve=$(this).attr('tp-of-modal-data');

modalEvent(modal_eve);

})

$(document).on('click','#new-test-add',function(){

add_tp_in_test();

})



$(document).on('click','.auta-main-dis-dash',function(){

$(".auta-main-dis-dash").map(function(){

$(this).removeClass("active-temp");

})

$(this).addClass("active-temp");

})


$(document).on('click','#select_temp_for_camp_test',function(){

temp_id=$(".active-temp").attr('id');

console.log(id_of_selected_camp_test);
img_back_url='https://scr.auftera.com/scr-api/?url=https://template.auftera.com/template/crt-template/crtedtemp/'+temp_id+'.html&width=700&height=800';

console.log($('[id-of-test-attr="'+id_of_selected_camp_test+'"]'));

$('[id-of-test-attr="'+id_of_selected_camp_test+'"]').children('.open_temp_choose_trg').attr("src",img_back_url);


$('[id-of-test-attr="'+id_of_selected_camp_test+'"]').attr("temp-id-of-test",temp_id);
modalclose("#sel-temp-modal-chs");
})




function modalEvent(button) {





		$("#"+button).addClass("open");


}






function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

    }, 5000);


}


function modalclose(ele){
$(ele).removeClass('open');

}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})



function modalclose(ele){
$(ele).removeClass('open');

}

append_txt_that_get_clck="";

function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}


</script>

<script>


</script>
